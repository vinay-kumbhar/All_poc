package com.vk.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocExceptionHandlingCustomApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocExceptionHandlingCustomApplication.class, args);
	}

}
