package com.vk.main.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.vk.main.exception.StudentServiceException;
import com.vk.main.model.StudentError;

@ControllerAdvice
public class ExceptionAdvice {
	@ExceptionHandler(StudentServiceException.class)
	public ResponseEntity<StudentError> mapStudentError(StudentServiceException se){
		
		System.out.println("3 in exceptionadvice");
		StudentError serror=new StudentError(HttpStatus.INTERNAL_SERVER_ERROR.value(),se.getMessage());
		
		return new ResponseEntity<StudentError>(serror ,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}

}
