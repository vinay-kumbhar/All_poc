package com.vk.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vk.main.exception.StudentServiceException;
import com.vk.main.model.Student;
import com.vk.main.serviceInterface.StudentService;

@RestController
public class StudentController {

	@Autowired
	StudentService studentService;

	@PostMapping("/studentData")
	public String SaveStudentData(@RequestBody Student s) {
		studentService.savedata(s);
		return "save data successsfully!!!!!";
	}

	@GetMapping("/getstudent/{sname}")
	public String getDataByName(@PathVariable String sname) throws StudentServiceException {
		Student ss = studentService.getstudentdata(sname);
		return ss.getName() + " is in " + ss.getDept() + " Department";

	}

	@GetMapping("/getstudentdata/{id}")
	public String getDataById(@PathVariable int id) throws StudentServiceException {
		Student student=studentService.getStudentdatabyId(id);
		System.out.println("2.5");
		return student.getId() +"id name is "+student.getName();
	}

}
