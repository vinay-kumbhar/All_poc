package com.vk.main.model;

public class StudentError {
	private int errorcode;
	private String studentmessage;
	public StudentError(int errorcode, String studentmessage) {
		super();
		this.errorcode = errorcode;
		this.studentmessage = studentmessage;
	}
	public StudentError() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(int errorcode) {
		this.errorcode = errorcode;
	}
	public String getStudentmessage() {
		return studentmessage;
	}
	public void setStudentmessage(String studentmessage) {
		this.studentmessage = studentmessage;
	}
	

}
