package com.vk.main.repositiory;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vk.main.model.Student;
@Repository
public interface StudentRepository extends JpaRepository<Student, Integer> {

	Student findByName(String s);
	
	Student findById(int id);

	

}
