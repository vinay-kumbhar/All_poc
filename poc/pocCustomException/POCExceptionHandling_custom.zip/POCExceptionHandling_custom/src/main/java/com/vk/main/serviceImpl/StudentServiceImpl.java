package com.vk.main.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vk.main.exception.StudentServiceException;
import com.vk.main.model.Student;
import com.vk.main.repositiory.StudentRepository;
import com.vk.main.serviceInterface.StudentService;

@Service
public class StudentServiceImpl implements StudentService {
	@Autowired
	StudentRepository studentrepository;

	@Override
	public void savedata(Student s) {

		studentrepository.save(s);

	}

	@Override
	public Student getstudentdata(String s) throws StudentServiceException {
		Student student = null;
		String dept = null;
		try {
			student = studentrepository.findByName(s);
			dept = student.getDept();
		} catch (Exception e) {
			throw new StudentServiceException("this studet is not available");
		}
		return student;
	}

	@Override
	public Student getStudentdatabyId(int id) throws StudentServiceException {
		Student student = null;
		String name = null;
		try {
			System.out.println("1");
			student = studentrepository.findById(id);
			name = student.getName();

		} catch (Exception e) {
			System.out.println("2");
			throw new StudentServiceException("data not present");

		}
		return student;
	}

}
