package com.vk.main.serviceInterface;

import com.vk.main.exception.StudentServiceException;
import com.vk.main.model.Student;

public interface StudentService {

	void savedata(Student s);

	Student getstudentdata(String s) throws StudentServiceException;

	Student getStudentdatabyId(int id) throws StudentServiceException;

}
