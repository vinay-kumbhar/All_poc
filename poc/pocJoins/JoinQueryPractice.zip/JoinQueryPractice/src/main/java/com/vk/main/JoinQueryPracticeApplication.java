package com.vk.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoinQueryPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoinQueryPracticeApplication.class, args);
	}

}
