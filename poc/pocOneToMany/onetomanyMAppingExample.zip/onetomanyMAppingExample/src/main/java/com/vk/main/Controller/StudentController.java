package com.vk.main.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.vk.main.ServiceI.StudentService;
import com.vk.main.model.Address;
import com.vk.main.model.Student;

@RestController
public class StudentController {

	@Autowired
	StudentService ss;

	@PostMapping("/savedata")
	public Student adddata(@RequestBody Student s) {
		return ss.savedata(s);

	}

	@GetMapping("/getdata")
	public List<Student> getdata() {
		return ss.getallData();
	}

	@PostMapping("/saveAddressData")
	public String saveAddress(@RequestBody List<Address> add) {
		ss.saveAddressdata(add);
		return "address save";
	}
    //delete address data
	@DeleteMapping("/deleteAddress/{id}")
	public String deleteStudentById(@PathVariable int id) {
		ss.deletedatabyid(id);
		return "deletedata";

	}
	@DeleteMapping("/deleteStudent/{sid}")
	public String deleteStudentid(@PathVariable int sid)
	{
		ss.studentdekete(sid);
		return "delete Student";
	}

}
