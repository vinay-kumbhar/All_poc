package com.vk.main.ServiceI;

import java.util.List;

import com.vk.main.model.Address;
import com.vk.main.model.Student;

public interface StudentService {

	Student savedata(Student s);

	List<Student> getallData();

	void saveAddressdata(List<Address> add);

	void deletedatabyid(int id);

	void studentdekete(int sid);

}
