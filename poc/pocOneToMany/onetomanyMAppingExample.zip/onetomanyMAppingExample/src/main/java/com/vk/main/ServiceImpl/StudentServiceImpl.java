package com.vk.main.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vk.main.ServiceI.StudentService;
import com.vk.main.StuRepository.AddressRepository;
import com.vk.main.StuRepository.StudentRepository;
import com.vk.main.model.Address;
import com.vk.main.model.Student;
@Service
public class StudentServiceImpl  implements StudentService{
	@Autowired
	StudentRepository sr;
	
	@Autowired
	AddressRepository addrepo;
	
	
	@Override
	public Student savedata(Student s) {
		
		return sr.save(s);
	}


	@Override
	public List<Student> getallData() {
		return sr.findAll();
	}


	@Override
	public void saveAddressdata(List<Address> add) {
		for(Address ad:add) {
		addrepo.save(ad);
		}
	}


	@Override
	public void deletedatabyid(int id) {
		// TODO Auto-generated method stub
		addrepo.deleteById(id);
		
	}


	@Override
	public void studentdekete(int sid) {
		sr.deleteById(sid);
	}

}
