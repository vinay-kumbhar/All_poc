package com.vk.main.StuRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vk.main.model.Address;
@Repository
public interface AddressRepository extends JpaRepository<Address, Integer>{

	void save(List<Address> add);
	

}
