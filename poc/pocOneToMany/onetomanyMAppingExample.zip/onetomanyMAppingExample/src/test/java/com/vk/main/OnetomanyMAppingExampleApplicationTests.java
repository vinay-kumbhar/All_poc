package com.vk.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetomanyMAppingExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
