package com.cjc.vls.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cjc.vls.main.model.User;
import com.cjc.vls.main.service.ServiceI;

@RestController
public class MainController {
	
	@Autowired
	private ServiceI s;
	
	@PostMapping("/postdata")
	public String m1(@RequestBody User user)
	{
		System.out.println("Data From Postman : "+user);
		s.addData(user);
		return "Done";
	}
	
	@GetMapping("/get/{id}")
	public User m2(@PathVariable("id") int id)
	{
		User u=s.getUserData(id);
		System.out.println(u.getAddress().getAid());
		System.out.println(u.getAddress().getCity());
		System.out.println(u.getAddress().getDist());
		return u;
	}
	
	@PutMapping("/up")
	public String m3(@RequestBody User user)
	{
		System.out.println("DAta Updated : "+user );
		s.updateUserData(user);
		return "Data Updated";
	}
	
   @DeleteMapping("/del/{id}")
   public String m4(@PathVariable("id") int id)
   {
	   s.deleteUserData(id);
	   return "Data Deleted";
   }
	
   @GetMapping("/allData")
   public List<User> m5()
   {
	   List<User> ulist=s.getAllData();  
	   return ulist;
   }
}
