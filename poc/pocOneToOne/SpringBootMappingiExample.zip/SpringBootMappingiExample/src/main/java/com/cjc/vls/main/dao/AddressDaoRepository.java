package com.cjc.vls.main.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cjc.vls.main.model.Address;

@Repository
public interface AddressDaoRepository extends JpaRepository<Address, Integer>{

}
