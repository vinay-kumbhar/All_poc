package com.cjc.vls.main.service;

import java.util.List;

import com.cjc.vls.main.model.User;

public interface ServiceI {
	
	void addData(User user);
	
	User getUserData(int id);
	
	void updateUserData(User user);
	
    void deleteUserData(int id);
    
    List<User> getAllData();
}
