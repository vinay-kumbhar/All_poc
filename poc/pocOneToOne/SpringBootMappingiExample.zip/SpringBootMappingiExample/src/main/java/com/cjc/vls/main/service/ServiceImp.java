package com.cjc.vls.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cjc.vls.main.dao.UserDaoRepository;
import com.cjc.vls.main.model.User;

@Service
public class ServiceImp implements ServiceI {
	
	@Autowired
	private UserDaoRepository ud;

	@Override
	public void addData(User user) {
	System.out.println("Service Layer : " +user);
	ud.save(user);
	}

	@Override
	public User getUserData(int id) {
		User u=ud.findById(id).get();
		return u;
	}

	@Override
	public void updateUserData(User user) {
		   ud.save(user);	
	}

	@Override
	public void deleteUserData(int id) {
		ud.deleteById(id);
	}

	@Override
	public List<User> getAllData() {	
		return ud.findAll();
	}

}
