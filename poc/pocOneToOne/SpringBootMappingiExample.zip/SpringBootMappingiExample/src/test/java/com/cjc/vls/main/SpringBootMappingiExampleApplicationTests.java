package com.cjc.vls.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMappingiExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
