package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Common;
import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepo;

@RestController
public class HomeController {

	@Autowired
	EmployeeRepo repo;

	@PostMapping("/empadd")

	public Employee add(@RequestBody Employee emp) {

		System.out.println(emp);

		return repo.save(emp);

	}

	@GetMapping("/all")
	public List<Employee> get() {

		return repo.findAll();

	}

	@GetMapping("/select")

	public List<Common> get1() {

		return repo.getjoin3();
	}

}
