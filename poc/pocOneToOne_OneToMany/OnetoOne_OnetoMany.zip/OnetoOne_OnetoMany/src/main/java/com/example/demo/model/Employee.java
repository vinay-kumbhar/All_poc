package com.example.demo.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
public class Employee {

	@Id
	@Column(name = "stu_id")
	private int id;
	@Column(name = "stu_name")
	private String name;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "stu_adhar")
	private AdharCard adhar;

}
