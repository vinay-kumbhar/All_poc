package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.AdharCard;

public interface AdharCardRepo extends JpaRepository<AdharCard, Integer>
{

}
