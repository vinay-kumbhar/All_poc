package com.example.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Common;
import com.example.demo.model.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	@Query("select new com.example.demo.model.Common( e.name,a.num,a1.aname ) "
			+ "FROM Employee e INNER JOIN e.adhar a INNER JOIN a.ladd a1")

	public List<Common> getjoin();

	@Query("select new com.example.demo.model.Common( e.name,a.num,a1.aname ) "
			+ "FROM Employee e RIGHT JOIN e.adhar a RIGHT JOIN a.ladd a1")

	public List<Common> getjoin2();

	@Query("select new com.example.demo.model.Common( e.name,a.num,a1.aname ) "
			+ "FROM Employee e LEFT JOIN e.adhar a LEFT JOIN a.ladd a1")

	public List<Common> getjoin3();

	/*
	 * @Query("select new com.example.demo.model.Common( e.name,a.num,a1.aname ) " +
	 * "FROM Employee e, AdharCard a,Address a1 where e.adhar.id=a.num AND a.ladd.num=a1.id"
	 * )
	 * 
	 * public List<Common> getjoin12();
	 */

}
