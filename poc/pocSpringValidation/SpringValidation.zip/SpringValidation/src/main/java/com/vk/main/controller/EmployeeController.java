package com.vk.main.controller;

import javax.validation.Valid;
import javax.xml.ws.RequestWrapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vk.main.dao.EmployeeRepo;
import com.vk.main.model.Employee;

@RestController
public class EmployeeController {
	
	
	@Autowired
	EmployeeRepo employeerepo;
	
	@PostMapping("/sedata")
	//@ResponseBody
	//@Validated
	public ResponseEntity<String> adddata(@Valid @RequestBody Employee emp,Errors errors) {
		if (errors.hasErrors()) {
			System.out.println(errors);
	       return new ResponseEntity<String>("======plz input proper data*======  " +errors,HttpStatus.BAD_REQUEST);
	         
	        
	        
	    }
	   // return new ResponseEntity(HttpStatus.OK);
//	}
		//return employeerepo.save(emp);
		employeerepo.save(emp);
		return null;
		
	}

}
